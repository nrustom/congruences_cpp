#ifndef POLY_H
#define POLY_H
#include <iostream>
#include <vector>

std::string poly_str(std::vector<int> &poly, std::string var = "X");

#endif
