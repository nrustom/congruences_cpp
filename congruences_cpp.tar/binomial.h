#ifndef BINOMIAL_H
#define BINOMIAL_H

long binomial_mod(long n, long k, int p, int m, int mod);


#endif
